﻿using System;

public interface ISaveGameEngine
{
	
}
