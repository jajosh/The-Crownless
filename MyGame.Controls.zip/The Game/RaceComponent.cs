﻿using System;

public class RaceComponent
{
	public RaceComponent()
	{
	}
}
