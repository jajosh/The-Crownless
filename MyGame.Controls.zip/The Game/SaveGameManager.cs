﻿using System;

public class SaveGameManager
{
	public static SaveGame GameState { get; set; }
	public SaveGameManager()
	{
	}
}
