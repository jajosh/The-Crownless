﻿using System;

public class MenuManager
{
	public MenuManager()
	{
	}
}
