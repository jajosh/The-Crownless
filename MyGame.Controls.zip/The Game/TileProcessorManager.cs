﻿using System;

public class TileProcessorManager : ITileProcessorEngine
{
	public TileProcessorManager()
	{
		TileProcessor processor = new TileProcessor();
	}
}
