﻿using NAudio.Wave;
using System;

//Structure of the beeper engine goes here. 
public interface IBeeperEngine
{

}
