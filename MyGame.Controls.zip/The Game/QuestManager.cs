﻿using System;

public class QuestManager()
{
   
    
}