﻿using System;

public class NPCData
{
	public NPCData()
	{
	}
}
