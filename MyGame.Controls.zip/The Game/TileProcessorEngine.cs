﻿using System;

public interface ITileProcessorEngine
{
	
}
