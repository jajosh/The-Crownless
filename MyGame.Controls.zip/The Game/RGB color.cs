﻿using System;

//public class ColorComponent
//{
//    public int R { get; set; }
//    public int G { get; set; }
//    public int B { get; set; }
//    public ColorComponent(int r, int g, int b)
//    {
//        R = r;
//        G = g;
//        B = b;
//    }
//    public Color ToColor() => Color.FromArgb(R, G, B);
//}