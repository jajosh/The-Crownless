﻿using System;

public interface INPCEngine
{
	
}
