﻿using System;

public class MapData
{
    public MapData()
	{
	}
}
