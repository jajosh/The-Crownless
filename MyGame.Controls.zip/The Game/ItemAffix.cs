﻿using System;

public class ItemAffix
{
	public ItemAffix()
	{
	}
}
