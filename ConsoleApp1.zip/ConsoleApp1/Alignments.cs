﻿using System;


public abstract class Alignments
{
    string name { get; }

}
